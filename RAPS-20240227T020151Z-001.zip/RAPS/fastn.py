from fastapi import FastAPI, UploadFile, File
from PIL import Image
from io import BytesIO
import util
from fastapi.responses import HTMLResponse

app = FastAPI()

@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html>
    <head>
        <style>
            [data-testid="stAppViewContainer"] {
                background-image: linear-gradient(to right top, #051937, #004d7a, #008793, #00bf72, #a8eb12);
            }
        </style>
    </head>
    <body>
        <h1>AI Managed Traffic System</h1>
        <form action="/upload" method="post" enctype="multipart/form-data">
            <input type="file" name="file">
            <input type="submit" value="Upload">
        </form>
    </body>
    </html>
    """

@app.post("/upload")
def upload_image(file: UploadFile = File(...)):
    image = Image.open(BytesIO(file.file.read()))
    # print(obj1)
    util.show_box(image)
    total_weight = util.pred(image)
    util.time_pred(total_weight)
    return {"message": "Image uploaded and processed successfully"}


import uvicorn
uvicorn.run(app, host="0.0.0.0", port=8000)
